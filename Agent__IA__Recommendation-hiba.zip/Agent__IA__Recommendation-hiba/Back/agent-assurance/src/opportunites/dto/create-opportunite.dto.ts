export class CreateOpportuniteDto {}
