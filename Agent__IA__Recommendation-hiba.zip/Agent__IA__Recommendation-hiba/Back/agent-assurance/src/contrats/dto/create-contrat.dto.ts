export class CreateContratDto {}
