export class CreateMappingProduitDto {}
