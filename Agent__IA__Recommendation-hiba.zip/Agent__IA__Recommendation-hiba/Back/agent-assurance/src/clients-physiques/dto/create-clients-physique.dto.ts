export class CreateClientsPhysiqueDto {}
