export class CreateClientsMoraleDto {}
