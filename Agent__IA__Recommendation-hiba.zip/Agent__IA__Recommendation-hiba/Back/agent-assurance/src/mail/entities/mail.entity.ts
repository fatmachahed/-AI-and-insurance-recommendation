export class Mail {}
