export class CreateMailDto {}
