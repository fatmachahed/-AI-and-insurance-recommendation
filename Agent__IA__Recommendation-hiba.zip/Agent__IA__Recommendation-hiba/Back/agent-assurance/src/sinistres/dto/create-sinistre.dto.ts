export class CreateSinistreDto {}
