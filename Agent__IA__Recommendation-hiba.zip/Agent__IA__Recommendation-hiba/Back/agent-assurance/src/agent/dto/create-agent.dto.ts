export class CreateAgentDto {}
