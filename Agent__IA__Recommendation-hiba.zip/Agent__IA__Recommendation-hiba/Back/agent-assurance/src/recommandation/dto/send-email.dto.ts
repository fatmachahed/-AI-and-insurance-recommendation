export class SendEmailDto {
  clientId: string;
  typeClient: "physique" | "morale";
  contractId: string;
}
