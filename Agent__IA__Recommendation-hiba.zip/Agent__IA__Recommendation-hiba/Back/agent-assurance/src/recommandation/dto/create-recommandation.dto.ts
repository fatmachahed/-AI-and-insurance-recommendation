export class CreateRecommandationDto {}
