export class Recommandation {}
