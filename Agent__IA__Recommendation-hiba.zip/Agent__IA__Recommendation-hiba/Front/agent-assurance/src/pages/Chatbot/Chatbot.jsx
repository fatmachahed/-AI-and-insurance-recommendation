export function Chatbot() {
  return (
    <div>
      <h1>Bienvenue dans le Chatbot 🤖</h1>
      <p>Ici tu pourras discuter avec ton assistant.</p>
    </div>
  )
}
